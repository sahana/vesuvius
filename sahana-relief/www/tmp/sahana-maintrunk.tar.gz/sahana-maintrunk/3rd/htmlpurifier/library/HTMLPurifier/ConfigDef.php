<?php

/**
 * Base class for configuration entity
 */
class HTMLPurifier_ConfigDef {
    var $class = false;
}

