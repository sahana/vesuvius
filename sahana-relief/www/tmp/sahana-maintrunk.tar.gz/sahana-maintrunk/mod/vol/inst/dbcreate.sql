CREATE TABLE `vol_skills` (
  `p_uuid` VARCHAR(60) NOT NULL,
  `opt_skill_code` varchar(100) default NULL
) ;
